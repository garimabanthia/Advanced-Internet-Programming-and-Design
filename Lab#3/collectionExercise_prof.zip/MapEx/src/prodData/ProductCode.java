package prodData;

public class ProductCode {
	private char cntryOfOrigin;
	private int deptCode;
	private String mfgCode;
	
	public ProductCode(char origin, int dept, String mfg) {
		cntryOfOrigin = origin;
		deptCode = dept;
		mfgCode = mfg;
	}

	public char getCntryOfOrigin() {
		return cntryOfOrigin;
	}

	public int getDeptCode() {
		return deptCode;
	}

	public String getMfgCode() {
		return mfgCode;
	}
	
	public String toString() {
		return cntryOfOrigin + "-" + deptCode + "-" + mfgCode;
	}
}
